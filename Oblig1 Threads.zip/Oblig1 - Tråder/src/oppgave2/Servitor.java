package oppgave2;

import java.util.concurrent.ThreadLocalRandom;

public class Servitor extends Thread {
	
	private HamburgerBrett brett;
	private String navn;
	private boolean fortsette = true;
	
	//Konstrukt�r
	public Servitor(HamburgerBrett brett, String navn) {
		this.brett = brett;
		this.navn = navn;
	}
	
	// Stopp metode
	public void stopp() {
		fortsette = false;
	}

	@Override
	public void run() {

		int tid = ThreadLocalRandom.current().nextInt(2,6);
		String utskrift = "";
		
		while(fortsette) {
			try {
				Thread.sleep(tid * 1000);
			} catch (InterruptedException e1) {
			}
			synchronized(brett) {
				
				//S� lenge brettet er tomt...
				while(brett.erTom()) {
					System.out.println(navn + " (servitor) �nsker � ta hamburger, men brett tomt. Venter!");
					try {
						//venter til flere burgere ankommer
						brett.wait();
						
					} catch (InterruptedException e) {
					}
				}
				//hvis brettet ikke er tomt, kan servit�r hente burger
				Hamburger burger = brett.fjern(); //fjerner burger fra brettet
					
					brett.notifyAll();
					utskrift = navn+ " (servitor) tar av hamburger " + burger + ". Brett:" + brett;
					System.out.println(utskrift);
			}
		}
		
	}
}
