package oppgave2;

public class Hamburger {
	
	//instansvariabler
	private int id = 1;
	private static int hjelp = 1;

	//konstrukt�r
	public Hamburger() {
		id++;
		this.id = hjelp;
		hjelp++;
	}
	
	@Override
	public String toString() {
		return "(" + id + ")";
	}
	
}
