package oppgave2;

import java.util.concurrent.ThreadLocalRandom;

public class Kokk extends Thread {
	
	private String navn;
	private HamburgerBrett brett;
	private boolean fortsette = true;
	
	public Kokk(HamburgerBrett brett,String navn) {
		this.brett = brett;
		this.navn = navn;
	}
	
	
	public void stopp() {
		fortsette = false;
	}
	
		@Override
		public void run() {

			int tid = ThreadLocalRandom.current().nextInt(2,6);
			String utskrift = "";
			
			while(fortsette) {
				try {
					Thread.sleep(tid * 1000);
				} catch (InterruptedException e1) {
				}
				synchronized(brett) {
					Hamburger burger = new Hamburger();
					
					//s�lenge brettet er fullt...
					while (!brett.ledigPlass()) {
						System.out.println(navn + " (kokk) klar med hamburger, men brett fullt. Venter!");
						try {
							brett.wait();
							
						} catch (InterruptedException e) {
						}
					}
					
					//hvis brettet er fullt, kan kokken lage nye hamburgere
							brett.leggTil(burger);
							brett.notifyAll();
							utskrift = navn + " (kokk) legger p� hamburger " + burger + ". Brett:" + brett;
							System.out.println(utskrift);
					
				}
			}
	}
}
