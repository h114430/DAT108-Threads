package oppgave2;

import java.util.ArrayList;
import java.util.List;

public class HamburgerBrett {
	
	//Instansvariabler
	private List<Hamburger> brett;
	private int kapasitet;
	
	//Konstrukt�r
	public HamburgerBrett(int kapasitet) {
		this.kapasitet = kapasitet;
		this.brett = new ArrayList<>(kapasitet);
	}
	//Metode for � legge til hamburger p� brettet
	public void leggTil(Hamburger burger) {
		this.brett.add(burger);
	}
	//Metode for fjerne hamburger fra brettet
	public Hamburger fjern() {
		return this.brett.remove(0);
	}
	//metode for � sjekke at brettet er tomt
	public boolean erTom() {
		return brett.isEmpty();
	}
	//metode for � sjekke om brettet har ledig plass
	public boolean ledigPlass() {
		return brett.size() < 4;
 	}
	@Override
	public String toString() {
		return "" + brett;
	}
}
