package oppgave3;

import java.util.concurrent.ThreadLocalRandom;

public class Kokk extends Thread {
	
	private String navn;
	private HamburgerBrett brett;
	private boolean fortsette = true;
	
	public Kokk(HamburgerBrett brett,String navn) {
		this.brett = brett;
		this.navn = navn;
	}
	
	
		@Override
		public void run() {

			int tid = ThreadLocalRandom.current().nextInt(2,6);
			String utskrift = "";
			
			while(fortsette) {
				
				Hamburger burger = new Hamburger();
				try {
					Thread.sleep(tid * 1000);
					brett.leggTil(burger);
					utskrift = navn + " (kokk) legger p� hamburger " + burger + ". Brett:" + brett;			
					System.out.println(utskrift);
				} catch (InterruptedException e) {
			}
		}
	}
}