package oppgave3;

import java.util.concurrent.ThreadLocalRandom;

public class Servitor extends Thread {
	
	private HamburgerBrett brett;
	private String navn;
	private boolean fortsette = true;
	
	//Konstrukt�r
	public Servitor(HamburgerBrett brett, String navn) {
		this.brett = brett;
		this.navn = navn;
	}

	@Override
	public void run() {

		int tid = ThreadLocalRandom.current().nextInt(2,6);
		String utskrift = "";
		
		while(fortsette) {
			try {
				Thread.sleep(tid * 1000);
				Hamburger burger = brett.fjern(); 
				utskrift = navn+ " (servitor) tar av hamburger " + burger + ". Brett:" + brett;
				System.out.println(utskrift);
			} catch (InterruptedException e1) {
			}
		}
	}
		
}
