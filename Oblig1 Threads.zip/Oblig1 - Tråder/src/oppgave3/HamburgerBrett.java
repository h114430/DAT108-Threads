package oppgave3;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class HamburgerBrett<Brett> {
	
	
	private BlockingQueue<Hamburger> brett;
	private int kapasitet;
	
	public HamburgerBrett(int kapasitet) {
		this.brett = new LinkedBlockingQueue<>(kapasitet);
		this.kapasitet = kapasitet;
	}
	
	//Metode for � legge til hamburger p� brettet
	public void leggTil(Hamburger burger) throws InterruptedException {
		this.brett.put(burger);
	}
	
	//Metode for fjerne hamburger fra brettet
	public Hamburger fjern() throws InterruptedException {
		return this.brett.take();
	}
	
	@Override
	public String toString() {
		return "" + brett;
	}
}
