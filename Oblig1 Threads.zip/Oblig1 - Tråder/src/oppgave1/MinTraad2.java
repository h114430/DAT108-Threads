package oppgave1;

import javax.swing.JOptionPane;

public class MinTraad2 extends Thread {
	
	String tekst2 = "";

	@Override
	public void run() {
		
		boolean kj�rer = true;
		while (kj�rer) {
			
			tekst2 = JOptionPane.showInputDialog("Skriv inn din melding. Tast 'quit' for � avslutte");
			MinTraad.setTekst(tekst2);
			if (tekst2.equals("quit")) {
				kj�rer = false;
			}
		}
	}
}