package oppgave1;

public class Oppgave1 {
	
public static void main(String[] args) throws InterruptedException {
	
		MinTraad t = new MinTraad();
		MinTraad2 u = new MinTraad2();
		
		t.start();
		
		u.start();
		u.join();
		
		if (!u.isAlive()) {
			t.makeFalse();
	    }
	}
}
