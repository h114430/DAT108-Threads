package oppgave1;

public class MinTraad extends Thread {
	
	public static String tekst = "Hallo verden";
	
	public static boolean kj�rer = true;
	
	public static void setTekst(String tekst) {
		MinTraad.tekst = tekst;
	}
	
	public boolean isKj�rer() {
		return kj�rer;
	}

	public void makeFalse() {
		kj�rer = false;
	}

	@Override
	public void run() {
		
		while (kj�rer) {
			System.out.println(tekst);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
	}
}
